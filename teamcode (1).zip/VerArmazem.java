/* Copyright (c) 2017 FIRST. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided that
 * the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list
 * of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 * list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * Neither the name of FIRST nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
 * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;



@Autonomous(name="Vermelho Armazem", group="Linear Opmode")

public class VerArmazem extends LinearOpMode {

	private DcMotor motordf = null;
	private DcMotor motordt = null;
	private DcMotor motoref = null;
	private DcMotor motoret = null;
	private DcMotor motor_carrossel = null;
	private DcMotor garra_direita = null;
	private DcMotor garra_esquerda = null;
	private DcMotor carrossel = null;
	private CRServo coletor = null;
	private Servo braco = null;

	@Override
	public void runOpMode() {
		telemetry.addData("Status", "Initialized");
		telemetry.update();

	motordf = hardwareMap.get(DcMotor.class, "df");
	motordt = hardwareMap.get(DcMotor.class, "dt");
	motoref = hardwareMap.get(DcMotor.class, "ef");
	motoret = hardwareMap.get(DcMotor.class, "et");
	carrossel = hardwareMap.get(DcMotor.class, "carrossel");
	coletor = hardwareMap.get(CRServo.class, "coletor_garra");
	braco = hardwareMap.get(Servo.class, "braco_garra");
	garra_direita = hardwareMap.get(DcMotor.class, "garra_direita");
	garra_esquerda = hardwareMap.get(DcMotor.class, "garra_esquerda");
		
		
	garra_direita.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
	garra_esquerda.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
		
	garra_direita.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
	garra_esquerda.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
		
		
	garra_direita.setDirection(DcMotorSimple.Direction.REVERSE);
		waitForStart();
	
		while(garra_direita.getCurrentPosition() > -360){
			garra_direita.setTargetPosition(-360);
			garra_esquerda.setTargetPosition(-360);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			sleep(1000);
			
			garra_direita.setPower(0.6);
			garra_esquerda.setPower(0.6);
		
			}
		braco.setPosition(1);
		
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(5000);
		
		motordf.setPower(-1*(0.6));
		motordt.setPower(-1*(0.6));
		motoref.setPower(1*(0.6));
		motoret.setPower(1*(0.6));
		sleep(200);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
	  	motordf.setPower(1*(0.6));
		motordt.setPower(1*(0.6));
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		//frente
		motordf.setPower(1*(0.6));
		motordt.setPower(1*(0.6));
		motoref.setPower(-1*(0.6));
		motoret.setPower(-1*(0.6));
		sleep(700);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		//deixa o bloco
		
		braco.setPosition(1);
		sleep(1000);
		coletor.setPower(-1);
		sleep(3000);
		coletor.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(-1*(0.6));
		motordt.setPower(-1*(0.6));
		motoref.setPower(1*(0.6));
		motoret.setPower(1*(0.6));
		sleep(300);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		braco.setPosition(-1);
		//baixa a garra
		while(garra_direita.getCurrentPosition() < 0){
			garra_direita.setTargetPosition(0);
			garra_esquerda.setTargetPosition(0);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
				
			garra_direita.setPower(0.4);
			garra_esquerda.setPower(0.4);
			}
		//braco.setPosition(-1);
		sleep(1000);

		//giro
		motordf.setPower(1*(0.6));
		motordt.setPower(1*(0.6));
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(700);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(-1);
		motordt.setPower(-1);
		motoref.setPower(1);
		motoret.setPower(1);
		sleep(1500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(10000);

		// run until the end of the match (driver presses STOP)
		while (opModeIsActive()) {

		}
	}
}
