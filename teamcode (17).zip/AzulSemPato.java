
package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.JavaUtil;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaCurrentGame;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import org.firstinspires.ftc.robotcore.external.tfod.Tfod;

@Autonomous(name = "AzulSemPato")
public class AzulSemPato extends LinearOpMode {

	private VuforiaCurrentGame vuforiaFreightFrenzy;
	private Tfod tfod;
	double vertical;
	double horizontal;
	double sentindo;

	private DcMotor motordf = null;
	private DcMotor motordt = null;
	private DcMotor motoref = null;
	private DcMotor motoret = null;
	private DcMotor motor_carrossel = null;
	private DcMotor garra_direita = null;
	private DcMotor garra_esquerda = null;
	private DcMotor carrossel = null;
	private CRServo coletor = null;
	private Servo braco = null;
	Recognition recognition;

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
  telemetry.addData("Status", "Initialized");
	telemetry.update();
		
	motordf = hardwareMap.get(DcMotor.class, "df");
	motordt = hardwareMap.get(DcMotor.class, "dt");
	motoref = hardwareMap.get(DcMotor.class, "ef");
	motoret = hardwareMap.get(DcMotor.class, "et");
	carrossel = hardwareMap.get(DcMotor.class, "carrossel");
	coletor = hardwareMap.get(CRServo.class, "coletor_garra");
	braco = hardwareMap.get(Servo.class, "braco_garra");
	garra_direita = hardwareMap.get(DcMotor.class, "garra_direita");
	garra_esquerda = hardwareMap.get(DcMotor.class, "garra_esquerda");
		
		
	garra_direita.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
	garra_esquerda.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
		
	garra_direita.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
	garra_esquerda.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
		
		
	garra_direita.setDirection(DcMotorSimple.Direction.REVERSE);
	motordf.setDirection(DcMotorSimple.Direction.REVERSE);
	motordt.setDirection(DcMotorSimple.Direction.REVERSE);
		//braco.setDirection(Servo.Direction.REVERSE);
		
	braco.setPosition(1);	
  
	List<Recognition> recognitions;
	int level;
	int index;

	vuforiaFreightFrenzy = new VuforiaCurrentGame();
	tfod = new Tfod();

	// Sample TFOD Op Mode
	// Initialize Vuforia.
	vuforiaFreightFrenzy.initialize(
		"", // vuforiaLicenseKey
		hardwareMap.get(WebcamName.class, "camera"), // cameraName
		"", // webcamCalibrationFilename
		true, // useExtendedTracking
		false, // enableCameraMonitoring
		null, // cameraMonitorFeedback
		0, // dx
		0, // dy
		0, // dz
		AxesOrder.XZY, // axesOrder
		90, // firstAngle
		90, // secondAngle
		0, // thirdAngle
		true); // useCompetitionFieldTargetLocations
	// Set min confidence threshold to 0.7
	tfod.initialize(vuforiaFreightFrenzy, (float) 0.7, true, true);
	// Initialize TFOD before waitForStart.
	// Activate TFOD here so the object detection labels are visible
	// in the Camera Stream preview window on the Driver Station.
	tfod.activate();
	// Enable following block to zoom in on target.
	tfod.setZoom(1, 16 / 9);
	telemetry.addData("DS preview on/off", "3 dots, Camera Stream");
	telemetry.addData(">", "Press Play to start");
	
	telemetry.update();
	// Wait for start command from Driver Station.
	waitForStart();
	// Put run blocks here.
	while (opModeIsActive()) {
	 
	  // Put loop blocks here.
	  // Get a list of recognitions from TFOD.
	  recognitions = tfod.getRecognitions();
	  // If list is empty, inform the user. Otherwise, go
	  // through list and display info for each recognition.
	  if (recognitions.size() == 0) {
		telemetry.addData("TFOD", "No items detected.");
	  } else {
		index = 0;
		// Iterate through list and call a function to
		// display info for each recognized object.
		for (Recognition recognition_item : recognitions) {
		  recognition = recognition_item;
		  // Display info.
		  displayInfo(index);
		  // Increment index.
		  index = index + 1;
		}
	  }
	  telemetry.addData("left", recognition.getLeft());
	  
	  sleep(1000);
	  
	  if(recognition.getLeft() > 0){
	  	
	  if (recognition.getLeft() < 180) {
		level = 3;
	  } else if (recognition.getLeft() < 380) {
		level = 2;
	  } else {
		level = 1;
	  }}else{
	  	level = 0;
	  }
	  
	  telemetry.addData("Level", level);
	  telemetry.update();
	  
	if (level == 3) {
		
	  	//Subir Garra
		while(garra_direita.getCurrentPosition() > -1100){
			garra_direita.setTargetPosition(-1100);
			garra_esquerda.setTargetPosition(-1100);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			sleep(1000);
			
			garra_direita.setPower(1);
			garra_esquerda.setPower(1);
		
			}
			
		braco.setPosition(0);
		
		//Horizontal
		motordf.setPower(0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(0.6);
		sleep(500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Giro
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(600);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Frente
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(100);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		//Deixar Bloco
		coletor.setPower(1);
		sleep(1000);
		coletor.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(0.6);
		motoret.setPower(0.6);
		sleep(200);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		braco.setPosition(1);
		sleep(1000);
		
		//Baixar Garra
		while(garra_direita.getCurrentPosition() < 0){
			garra_direita.setTargetPosition(0);
			garra_esquerda.setTargetPosition(0);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
				
			garra_direita.setPower(0.7);
			garra_esquerda.setPower(0.7);
			}
			
				
		//giro
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(200);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Horizontal
		motordf.setPower(-0.6);
		motordt.setPower(0.6);
		motoref.setPower(0.6);
		motoret.setPower(-0.6);
		sleep(500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(1);
		motordt.setPower(1);
		motoref.setPower(1);
		motoret.setPower(1);
		sleep(1500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(10000);
	
		
		}
	else if (level == 2) {
		//Subir Garra
		while(garra_direita.getCurrentPosition() > -1000){
			garra_direita.setTargetPosition(-1000);
			garra_esquerda.setTargetPosition(-1000);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			sleep(1000);
			
			garra_direita.setPower(1);
			garra_esquerda.setPower(1);
		
			}
			
		braco.setPosition(0);
		
		//Horizontal
		motordf.setPower(0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(0.6);
		sleep(500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Giro
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(600);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Frente
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(300);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		//Deixar Bloco
		coletor.setPower(1);
		sleep(1000);
		coletor.setPower(0);
		sleep(100);
		
		//tras
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(0.6);
		motoret.setPower(0.6);
		sleep(200);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		braco.setPosition(1);
		sleep(1000);
		
		//Baixar Garra
		while(garra_direita.getCurrentPosition() < 0){
			garra_direita.setTargetPosition(0);
			garra_esquerda.setTargetPosition(0);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
				
			garra_direita.setPower(0.9);
			garra_esquerda.setPower(0.9);
			}
			
				
		//giro
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(200);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Horizontal
		motordf.setPower(-0.6);
		motordt.setPower(0.6);
		motoref.setPower(0.6);
		motoret.setPower(-0.6);
		sleep(500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(1);
		motordt.setPower(1);
		motoref.setPower(1);
		motoret.setPower(1);
		sleep(1500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(10000);
		
	}
	else if (level == 1){
		
		//Subir Garra
		while(garra_direita.getCurrentPosition() > -810){
			garra_direita.setTargetPosition(-810);
			garra_esquerda.setTargetPosition(-810);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			sleep(1000);
			
			garra_direita.setPower(1);
			garra_esquerda.setPower(1);
		
			}
			
		braco.setPosition(0);
		
		//Horizontal
		motordf.setPower(0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(0.6);
		sleep(500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Giro
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(650);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Frente
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		//Deixar Bloco
		coletor.setPower(1);
		sleep(1000);
		coletor.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(0.6);
		motoret.setPower(0.6);
		sleep(200);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		braco.setPosition(1);
		sleep(1000);
		
		//Baixar Garra
		while(garra_direita.getCurrentPosition() < 0){
			garra_direita.setTargetPosition(0);
			garra_esquerda.setTargetPosition(0);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
				
			garra_direita.setPower(0.7);
			garra_esquerda.setPower(0.7);
			}
			
		//giro
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(200);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Horizontal
		motordf.setPower(-0.6);
		motordt.setPower(0.6);
		motoref.setPower(0.6);
		motoret.setPower(-0.6);
		sleep(500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(1);
		motordt.setPower(1);
		motoref.setPower(1);
		motoret.setPower(1);
		sleep(1500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(10000);
			
			
		
	}
	else{
				//Subir Garra
		while(garra_direita.getCurrentPosition() > -850){
			garra_direita.setTargetPosition(-850);
			garra_esquerda.setTargetPosition(-850);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			sleep(1000);
			
			garra_direita.setPower(1);
			garra_esquerda.setPower(1);
		
			}
			
		braco.setPosition(0);
		
		//Horizontal
		motordf.setPower(0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(0.6);
		sleep(400);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Giro
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(600);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Frente
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(1100);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		//Deixar Bloco
		coletor.setPower(1);
		sleep(3000);
		coletor.setPower(0);
		sleep(1000);
		
		braco.setPosition(1);
		sleep(1000);
		
		//Baixar Garra
		while(garra_direita.getCurrentPosition() < 0){
			garra_direita.setTargetPosition(0);
			garra_esquerda.setTargetPosition(0);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
				
			garra_direita.setPower(0.7);
			garra_esquerda.setPower(0.7);
			}
			
		//Giro
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(300);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Horizontal
		motordf.setPower(0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(0.6);
		sleep(300);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Tras
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(0.6);
		motoret.setPower(0.6);
		sleep(1800);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(100);
		
		//Carrossel
		carrossel.setPower(0.8);
		sleep(2000);
		
		//Frente
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(400);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
	}

	vuforiaFreightFrenzy.close();
	tfod.close();
  }
}
  /**
   * Display info (using telemetry) for a recognized object.
   */
  private void displayInfo(int i) {
	// Display label info.
	// Display the label and index number for the recognition.
	telemetry.addData("label " + i, recognition.getLabel());
	// Display upper corner info.
	// Display the location of the top left corner
	// of the detection boundary for the recognition
	telemetry.addData("Left, Top " + i, Double.parseDouble(JavaUtil.formatNumber(recognition.getLeft(), 0)) + ", " + Double.parseDouble(JavaUtil.formatNumber(recognition.getTop(), 0)));
	// Display lower corner info.
	// Display the location of the bottom right corner
	// of the detection boundary for the recognition
	telemetry.addData("Right, Bottom " + i, Double.parseDouble(JavaUtil.formatNumber(recognition.getRight(), 0)) + ", " + Double.parseDouble(JavaUtil.formatNumber(recognition.getBottom(), 0)));
  }
}
