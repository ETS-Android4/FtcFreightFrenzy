package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

@Autonomous(name="BlueCarrossel", group="Linear Opmode")

public class BlueCarrossel extends LinearOpMode {

	private DcMotor motordf = null;
	private DcMotor motordt = null;
	private DcMotor motoref = null;
	private DcMotor motoret = null;
	private DcMotor motor_carrossel = null;
	private DcMotor garra_direita = null;
	private DcMotor garra_esquerda = null;
	private DcMotor carrossel = null;
	private CRServo coletor = null;
	private Servo braco = null;
	
	@Override
	public void runOpMode() {

	telemetry.addData("Status", "Initialized");
	telemetry.update();

//--------------------------------Configurando Motores--------------------------
	motordf = hardwareMap.get(DcMotor.class, "df");
	motordt = hardwareMap.get(DcMotor.class, "dt");
	motoref = hardwareMap.get(DcMotor.class, "ef");
	motoret = hardwareMap.get(DcMotor.class, "et");
	carrossel = hardwareMap.get(DcMotor.class, "carrossel");
	coletor = hardwareMap.get(CRServo.class, "coletor_garra");
	braco = hardwareMap.get(Servo.class, "braco_garra");
	garra_direita = hardwareMap.get(DcMotor.class, "garra_direita");
	garra_esquerda = hardwareMap.get(DcMotor.class, "garra_esquerda");
		
		
	garra_direita.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
	garra_esquerda.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
		
	garra_direita.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
	garra_esquerda.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
		
		
	garra_direita.setDirection(DcMotorSimple.Direction.REVERSE);
	motordf.setDirection(DcMotorSimple.Direction.REVERSE);
	motordt.setDirection(DcMotorSimple.Direction.REVERSE);
	
	waitForStart();
//------------------------------------------------------------------------------
	
//------------------------------Codigo Autonomo---------------------------------
		
		//Subir Garra
		while(garra_direita.getCurrentPosition() > -850){
			garra_direita.setTargetPosition(-850);
			garra_esquerda.setTargetPosition(-850);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			sleep(1000);
			
			garra_direita.setPower(1);
			garra_esquerda.setPower(1);
		
			}
			
		braco.setPosition(0);
		
		//Horizontal
		motordf.setPower(0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(0.6);
		sleep(400);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Giro
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(600);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Frente
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(1100);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		//Deixar Bloco
		coletor.setPower(1);
		sleep(3000);
		coletor.setPower(0);
		sleep(1000);
		
		braco.setPosition(1);
		sleep(1000);
		
		//Baixar Garra
		while(garra_direita.getCurrentPosition() < 0){
			garra_direita.setTargetPosition(0);
			garra_esquerda.setTargetPosition(0);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
				
			garra_direita.setPower(0.7);
			garra_esquerda.setPower(0.7);
			}
			
		//Giro
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(300);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Horizontal
		motordf.setPower(0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(0.6);
		sleep(300);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//Tras
		motordf.setPower(0.6);
		motordt.setPower(0.6);
		motoref.setPower(0.6);
		motoret.setPower(0.6);
		sleep(1800);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(100);
		
		//Carrossel
		carrossel.setPower(0.8);
		sleep(2000);
		
		//Frente
		motordf.setPower(-0.6);
		motordt.setPower(-0.6);
		motoref.setPower(-0.6);
		motoret.setPower(-0.6);
		sleep(400);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		
		
		

//------------------------------------------------------------------------------
	}
}
