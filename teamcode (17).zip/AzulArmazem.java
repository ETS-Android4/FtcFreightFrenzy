package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

@Autonomous(name="AzulArmazem", group="Linear Opmode")

public class AzulArmazem extends LinearOpMode {
	
	private DcMotor motordf = null;
	private DcMotor motordt = null;
	private DcMotor motoref = null;
	private DcMotor motoret = null;
	private DcMotor motor_carrossel = null;
	private DcMotor garra_direita = null;
	private DcMotor garra_esquerda = null;
	private DcMotor carrossel = null;
	private CRServo coletor = null;
	private Servo braco = null;

	@Override
	public void runOpMode() {
		telemetry.addData("Status", "Initialized");
		telemetry.update();
		
	motordf = hardwareMap.get(DcMotor.class, "df");
	motordt = hardwareMap.get(DcMotor.class, "dt");
	motoref = hardwareMap.get(DcMotor.class, "ef");
	motoret = hardwareMap.get(DcMotor.class, "et");
	carrossel = hardwareMap.get(DcMotor.class, "carrossel");
	coletor = hardwareMap.get(CRServo.class, "coletor_garra");
	braco = hardwareMap.get(Servo.class, "braco_garra");
	garra_direita = hardwareMap.get(DcMotor.class, "garra_direita");
	garra_esquerda = hardwareMap.get(DcMotor.class, "garra_esquerda");
		
		
	garra_direita.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
	garra_esquerda.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
		
	garra_direita.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
	garra_esquerda.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
		
		
	garra_direita.setDirection(DcMotorSimple.Direction.REVERSE);

		waitForStart();
		
			
		while(garra_direita.getCurrentPosition() > -360){
			garra_direita.setTargetPosition(-360);
			garra_esquerda.setTargetPosition(-360);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			sleep(1000);
			
			garra_direita.setPower(0.6);
			garra_esquerda.setPower(0.6);
		
			}
		braco.setPosition(1);
		
	  	motordf.setPower(1*(0.6));
		motordt.setPower(1*(0.6));
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		//frente
		motordf.setPower(1*(0.6));
		motordt.setPower(1*(0.6));
		motoref.setPower(-1*(0.6));
		motoret.setPower(-1*(0.6));
		sleep(600);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		
		//deixa o bloco
		
		braco.setPosition(1);
		sleep(1000);
		coletor.setPower(-1);
		sleep(3000);
		coletor.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(-1*(0.6));
		motordt.setPower(-1*(0.6));
		motoref.setPower(1*(0.6));
		motoret.setPower(1*(0.6));
		sleep(200);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		braco.setPosition(-1);
		//baixa a garra
		while(garra_direita.getCurrentPosition() < 0){
			garra_direita.setTargetPosition(0);
			garra_esquerda.setTargetPosition(0);
				
			garra_direita.setMode(DcMotor.RunMode.RUN_TO_POSITION);
			garra_esquerda.setMode(DcMotor.RunMode.RUN_TO_POSITION);
				
			garra_direita.setPower(0.4);
			garra_esquerda.setPower(0.4);
			}
		//braco.setPosition(-1);
		sleep(1000);

		//giro
		motordf.setPower(-1*(0.6));
		motordt.setPower(-1*(0.6));
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(1000);
		
		//tras
		motordf.setPower(-1);
		motordt.setPower(-1);
		motoref.setPower(1);
		motoret.setPower(1);
		sleep(1500);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(10000);
		

		while (opModeIsActive()) {

		}
	}
}
