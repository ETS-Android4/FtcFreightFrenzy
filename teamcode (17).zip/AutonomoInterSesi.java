package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.Range;

@Autonomous(name="Basic: Linear OpMode", group="Linear Opmode")

public class AutonomoInterSesi extends LinearOpMode {

	// Declare membros OpMode
	private ElapsedTime runtime = new ElapsedTime();
	private DcMotor motor_direitaf= null;
	private DcMotor motor_direitat = null;
	private DcMotor motor_esquerdaf = null;
	private DcMotor motor_esquerdat = null;
	private DcMotor cirilo = null;

	@Override
	public void runOpMode() {
		telemetry.addData("Status", "Initialized");
		telemetry.update();
		
		
		motor_direitaf = hardwareMap.get(DcMotor.class, "df");
		motor_direitat = hardwareMap.get(DcMotor.class, "dt");
		motor_esquerdaf = hardwareMap.get(DcMotor.class, "ef");
		motor_esquerdat = hardwareMap.get(DcMotor.class, "et");
		cirilo = hardwareMap.get(DcMotor.class, "motor_cirilo" );
		

		motor_direitaf.setDirection(DcMotor.Direction.FORWARD);
		motor_direitat.setDirection(DcMotor.Direction.FORWARD);
		
		//Invertendo os motores 
		motor_esquerdaf.setDirection(DcMotor.Direction.REVERSE);
		motor_esquerdat.setDirection(DcMotor.Direction.REVERSE);

		
		waitForStart();
		runtime.reset();

		
		if(opModeIsActive()) {
			
			//O robô esta andando para a frente
			motor_direitaf.setPower(1);
			motor_direitat.setPower(1);
			motor_esquerdaf.setPower(-1);
			motor_esquerdat.setPower(-1);
			sleep(900);
			
			//Dando uma pausa para a proxima execução
			motor_direitaf.setPower(0);
			motor_direitat.setPower(0);
			motor_esquerdaf.setPower(0);
			motor_esquerdat.setPower(0);
			sleep(500);
			
			//O robô vai andar para a direita
			motor_direitaf.setPower(-1);
			motor_direitat.setPower(1);
			motor_esquerdaf.setPower(1);
			motor_esquerdat.setPower(-1);
			sleep(900);
			
			//Dando uma pausa para a proxima execução
			motor_direitaf.setPower(0);
			motor_direitat.setPower(0);
			motor_esquerdaf.setPower(0);
			motor_esquerdat.setPower(0);
			sleep(500);
			
			//Indo para tras para o robô se ajustar com o carrossel
			motor_direitaf.setPower(-1);
			motor_direitat.setPower(-1);
			motor_esquerdaf.setPower(1);
			motor_esquerdat.setPower(1);
			sleep(500);
			
			//Dando uma pausa para a proxima execução
			motor_direitaf.setPower(0);
			motor_direitat.setPower(0);
			motor_esquerdaf.setPower(0);
			motor_esquerdat.setPower(0);
			sleep(500);
			
			//acionando o carrossel 
			cirilo.setPower(1);
			sleep(500);
			
			//Dando uma pausa para a proxima execução
			cirilo.setPower(0);
			sleep(500);
			
			//Finalizando com o robô indo para frente
			motor_direitaf.setPower(1);
			motor_direitat.setPower(1);
			motor_esquerdaf.setPower(-1);
			motor_esquerdat.setPower(-1);
			sleep(800);
			
			//Dando uma pausa para a proxima execução
			motor_direitaf.setPower(0);
			motor_direitat.setPower(0);
			motor_esquerdaf.setPower(0);
			motor_esquerdat.setPower(0);
			sleep(500);
			
		}
	}
}
