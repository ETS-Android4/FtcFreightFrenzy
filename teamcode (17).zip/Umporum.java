

package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;


@Autonomous(name="TesteMotores", group="Linear Opmode")

public class Umporum extends LinearOpMode {

	// Declare OpMode members for each of the 4 motors.
	private ElapsedTime runtime = new ElapsedTime();
	private DcMotor motordf = null;
	private DcMotor motordt = null;
	private DcMotor motoref = null;
	private DcMotor motoret = null;

	@Override
	public void runOpMode() {

	   
		motordf  = hardwareMap.get(DcMotor.class, "df");
		motordt = hardwareMap.get(DcMotor.class, "dt");
		motoref = hardwareMap.get(DcMotor.class, "ef");
		motoret = hardwareMap.get(DcMotor.class, "et");

		motordf.setDirection(DcMotor.Direction.REVERSE);
		motordt.setDirection(DcMotor.Direction.REVERSE);


		telemetry.addData("Status", "Initialized");
		telemetry.update();

		waitForStart();
		runtime.reset();
		
		
		motordf.setPower(0.3);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(3000);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(2000);
		motordt.setPower(0.3);
		motordf.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(3000);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(2000);
		motoref.setPower(0.3);
		motordf.setPower(0);
		motordt.setPower(0);
		motoret.setPower(0);
		sleep(3000);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(2000);
		motoret.setPower(0.3);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		sleep(3000);
		motordf.setPower(0);
		motordt.setPower(0);
		motoref.setPower(0);
		motoret.setPower(0);
		sleep(2000);
		
	}}
